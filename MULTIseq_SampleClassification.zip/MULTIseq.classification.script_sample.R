#############################################
## Sample MULTI-seq Classification Scipt ####
## Chris McGinnis Gartner Lab UCSF 12/3/18 ##
#############################################

library(KernSmooth)
library(ggplot2)
library(reshape2)

source("/Path/To/LocalMaxima.R")
source("/Path/To/FindThresh.R")
source("/Path/To/ClassifyCells.R")

##########################################
## Step 1: Read in barcode count matrix ##
##########################################
## NOTE: Barcodes = columns, CellIDs = rows
bar.table <- read.csv(file="/path/to/barcode.count.matrix.csv", header=TRUE, stringsAsFactors = FALSE)

#############################################################
## Step 2: Determine cell classifications across quantiles ##
#############################################################
bar.table_sweep.list <- list()
n <- 0
for (q in seq(0.01, 0.99, by=0.02)) {
  print(q)
  n <- n + 1
  bar.table_sweep.list[[n]] <- classifyCells(data=bar.table, q=q)
  names(bar.table_sweep.list)[n] <- paste("q=",q,sep="")
}

##############################################################
## Step 3: Identify optimal quantile by maximizing pSinglet ##
##############################################################
findThresh(call.list=bar.table_sweep.list, id="round1")
ggplot(data=res_round1, aes(x=q, y=Proportion, color=Subset)) + geom_line() + 
  geom_vline(xintercept=extrema_round1, lty=2) + scale_color_manual(values=c("red","black","blue"))

#################################################################
## Step 4: Perform round 1 classification using ideal quantile ##
#################################################################
round1.calls <- classifyCells(bar.table, q=...)

##################################################################################
## Step 5: Remove negative cells and repeat steps 2-4 until no negatives remain ##
##################################################################################
## Remove negative cells
neg.cells <- names(round1.calls)[which(round1.calls == "Negative")]
bar.table2 <- bar.table[-which(rownames(bar.table) %in% neg.cells), ]

## Repeat step 2
bar.table_sweep.list2 <- list()
n <- 0
for (q in seq(0.01, 0.99, by=0.02)) {
  print(q)
  n <- n + 1
  bar.table_sweep.list2[[n]] <- classifyCells(data=bar.table2, q=q)
  names(bar.table_sweep.list2)[n] <- paste("q=",q,sep="")
}

## Repeat step 3
findThresh(call.list=bar.table_sweep.list2, id="round2")
ggplot(data=res_round2, aes(x=q, y=Proportion, color=Subset)) + geom_line() + 
  geom_vline(xintercept=extrema_round2, lty=2) + scale_color_manual(values=c("red","black","blue"))

## Repeat step 4
round2.calls <- classifyCells(bar.table2, q=...)

## If number of negative cells != 0, repeat procedure until negative cells == 0
neg.cells <- c(neg.cells, names(round2.calls)[which(round2.calls == "Negative")])
bar.table3 <- bar.table[-which(rownames(bar.table) %in% neg.cells), ]
               
