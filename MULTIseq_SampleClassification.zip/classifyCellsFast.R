#####################################################
## Perturb-Seq x CellHashing sample classification ##
## Chris McGinnis, Jennifer Hu, Gartner Lab UCSF ####
#####################################################

classifyCells <- function(data, q) {
  require(KernSmooth)
  
  ## Normalize Data: Log2 Transform, mean-center
  data.n <- as.data.frame(log2(data))
  for (i in 1:ncol(data)) {
    ind <- which(is.finite(data.n[,i]) == FALSE)
    data.n[ind,i] <- 0
    data.n[,i] <- data.n[,i]-mean(data.n[,i])
  }
  
  ## Pre-allocate memory to save processing time/memory
  n_BC <- ncol(data.n) # Number of barcodes
  n_cells <- nrow(data.n) # Numer of cells
  bc_calls <- rep("Negative",n_cells) # Barcode classification for each cell
  names(bc_calls) <- rownames(data.n)
  
  ## Generate thresholds for each barcode: 
  ## 1. Gaussian KDE with bad barcode detection, outlier trimming
  ## 2. Define local maxima for GKDE 
  ## 3. Split maxima into low and high subsets, adjust low if necessary
  ## 4. Threshold and classify cells according to user-specified inter-maxima quantile
  
  for (i in 1:n_BC) {
    ## Step 1: GKDE
    model <- tryCatch( { approxfun(bkde(data.n[,i], kernel="normal")) },
                       error=function(e) { print(paste0("No threshold found for ", colnames(data.n)[i],"...")) } )
    if (class(model) == "character") { next }
    x <- seq(from=quantile(data.n[,i],0.001), to=quantile(data.n[,i],0.999), length.out=100)
    
    ## Step 2: Local maxima definition
    extrema <- localMaxima(model(x))
    if (length(extrema) <= 1) {
      print(paste0("No threshold found for ", colnames(data.n)[i],"..."))
      next
    }
    
    ## Step 3: Adjust local maxima (if necessary)
    low.extreme <- min(extrema)
    high.extreme <- max(extrema)
    thresh <- (x[high.extreme] + x[low.extreme])/2
    low.extrema <- extrema[which(x[extrema] <= thresh)]
    new.low <- low.extrema[which.max(model(x)[low.extrema])]
    
    ## Step 4: Threshold and classify cells
    thresh <- quantile(c(x[high.extreme], x[new.low]), q)
    cell_i <- which(data.n[,i] >= thresh)
    n <- length(cell_i)
    if (n == 0) { next } # Skip to next barcode if no cells classified
    bc_calls[cell_i] <- sapply(bc_calls[cell_i],
                               FUN = function(x) {
                                 if (x == "Negative") { 
                                   return(colnames(data.n)[i]) 
                                 } else { 
                                   return("Doublet") 
                                 } })
  }
  
  return(bc_calls)
  
}