##################################################################
## Inter-maxima quantile sweep to find ideal barcode thresholds ##
## Chris McGinnis, Gartner Lab UCSF 07/27/2018 ###################
##################################################################

findThresh <- function(call.list, id) {
  require(reshape2); require(ggplot2); require(splus2R)
  
  res <- as.data.frame(matrix(0L, nrow=length(call.list), ncol=4))
  colnames(res) <- c("q","pDoublet","pNegative","pSinglet")
  q.range <- unlist(strsplit(names(call.list), split="q="))
  res$q <- as.numeric(q.range[grep("0", q.range)])
  nCell <- length(call.list[[1]])
  
  for (i in 1:nrow(res)) {
    temp <- table(call.list[[i]])
    if ( "Doublet" %in% names(temp) == TRUE ) { res$pDoublet[i] <- temp[which(names(temp) == "Doublet")] }
    if ( "Negative" %in% names(temp) == TRUE ) { res$pNegative[i] <- temp[which(names(temp) == "Negative")] }
    res$pSinglet[i] <- sum(temp[which(names(temp) != "Doublet" & names(temp) != "Negative")])
  }
  
  res <- melt(res, id.vars="q")
  res[,4] <- res$value/nCell
  colnames(res)[2:4] <- c("Subset","nCells","Proportion")
  assign(x=paste("res_",id,sep=""), value=res, envir = .GlobalEnv)
  
  extrema <- res$q[localMaxima(res$Proportion[which(res$Subset == "pSinglet")])]
  assign(x=paste("extrema_",id,sep=""), value=extrema, envir = .GlobalEnv)
}











