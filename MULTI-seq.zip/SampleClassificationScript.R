#####################################
## MULTI-seq Sample Classification ##
## Chris McGinnis Gartner Lab UCSF ##
#####################################

library(KernSmooth)
library(ggplot2)
library(reshape2)

source("/Path/To/LocalMaxima.R")
source("/Path/To/FindThresh.R")
source("/Path/To/ClassifyCells.R")

## Step 1A: Read in CITE-seq Count output ~ Remove unused barcodes + summary statistics
## Rows = cells, Columns = barcodes
bar.table <- read.csv("CiteSeqCount_Output.tsv", header=TRUE, stringsAsFactors = FALSE)

## Step 1B: Compute and visually-inspect ideal inter-maxima threshold
bar.table_sweep.list <- list()
n <- 0
for (q in seq(0.01, 0.99, by=0.02)) {
  print(q)
  n <- n + 1
  bar.table_sweep.list[[n]] <- classifyCells(data=bar.table, q=q)
  names(bar.table_sweep.list)[n] <- paste("q=",q,sep="")
}

findThresh(call.list=bar.table_sweep.list, id="round1")
ggplot(data=res_round1, aes(x=q, y=Proportion, color=Subset)) + geom_line() + 
  geom_vline(xintercept=extrema_round1, lty=2) + scale_color_manual(values=c("red","black","blue"))

## Step 1C: Perform round1 classification -- use q defined using findThresh
round1.calls <- classifyCells(pdx_med.table, q=...)

## Step 1D: Find new inter-maxima threshold for data without negative cells and plot results
neg.cells <- names(round1.calls)[which(round1.calls == "Negative")]
bar.table2 <- bar.table[-which(rownames(bar.table) %in% neg.cells), ]
bar.table_sweep.list2 <- list()
n <- 0
for (q in seq(0.01, 0.99, by=0.02)) {
  print(q)
  n <- n + 1
  bar.table_sweep.list2[[n]] <- classifyCells(data=bar.table2, q=q)
  names(bar.table_sweep.list2)[n] <- paste("q=",q,sep="")
}
findThresh(call.list=bar.table_sweep.list2, id="round2")
ggplot(data=res_round2, aes(x=q, y=Proportion, color=Subset)) + geom_line() + 
  geom_vline(xintercept=extrema_round2, lty=2) + scale_color_manual(values=c("red","black","blue"))

## Step 1E: Round2 classification
## Check number of negative cells with table(round2.calls)
round2.calls <- classifyCells(bar.table2, q=...)

## If numberof negative cells != 0, repeat procedure until negative cells == 0

## Step 1F: (OPTIONAL) Repeat previous steps for 3rd round
neg.cells <- c(neg.cells, names(round2.calls)[which(round2.calls == "Negative")])
bar.table3 <- pdx_med.table[-which(rownames(bar.table2) %in% neg.cells), ]
bar.table_sweep.list3 <- list()
n <- 0
for (q in seq(0.01, 0.99, by=0.02)) {
  print(q)
  n <- n + 1
  bar.table_sweep.list3[[n]] <- classifyCells(data=bar.table3, q=q)
  names(bar.table_sweep.list3)[n] <- paste("q=",q,sep="")
}
findThresh(call.list=bar.table_sweep.list3, id="round3")
ggplot(data=res_round3, aes(x=q, y=Proportion, color=Subset)) + geom_line() + 
  geom_vline(xintercept=extrema_round3, lty=2) + scale_color_manual(values=c("red","black","blue"))
round3.calls <- classifyCells(bar.table3, q=...)

