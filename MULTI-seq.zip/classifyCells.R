#####################################################
## Perturb-Seq x CellHashing sample classification ##
## Chris McGinnis, Gartner Lab UCSF, 07/27/2018 #####
#####################################################

classifyCells <- function(data, q) {
  require(KernSmooth)
  
  ## Normalize Data: Log2 Transform, replace -Infs, mean-center
  print("Normalizing Data...")
  data.n <- as.data.frame(log2(data))
  for (i in 1:ncol(data)) {
    ind <- which(is.finite(data.n[,i]) == FALSE)
    data.n[ind,i] <- 0
    data.n[,i] <- data.n[,i]-mean(data.n[,i])
  }
  
  ## Generate Thresholds: Gaussian KDE with bad barcode detection, outlier trimming
  ## local maxima estiamtion with bad barcode detection, threshold definition and adjustment
  thresholds <- NULL
  bcs <- NULL
  for (i in 1:ncol(data.n)) {
    model <- tryCatch( { approxfun(bkde(data.n[,i], kernel="normal")) }, 
                       error=function(e) { print(paste("No threshold found for ", colnames(data.n)[i],"...",sep="")) } )
    if (class(model) == "character") { next }
    x <- seq(from=quantile(data.n[,i],0.001), to=quantile(data.n[,i],0.999), length.out=100)    
    extrema <- localMaxima(model(x))
    if (length(extrema) <= 1) { 
      print(paste("No threshold found for ", colnames(data.n)[i],"...",sep=""))
      next
    }
    low.extrema <- min(extrema)
    high.extrema <- max(extrema)
    thresh <- (x[high.extrema] + x[low.extrema])/2
    
    low.extremae <- extrema[which(x[extrema] <= thresh)]
    new.low <- low.extremae[which.max(model(x)[low.extremae])]
    thresh <- quantile(c(x[high.extrema], x[new.low]), q)
    thresholds <- c(thresholds, thresh)
    bcs <- c(bcs, colnames(data.n)[i])
  }
  
  # Make classification matrix
  print("Making Classification Matrix...")
  call.mat <- as.data.frame(matrix(0L, nrow=nrow(data.n), ncol=length(bcs)))
  rownames(call.mat) <- rownames(data.n)
  colnames(call.mat) <- bcs
  for (i in 1:length(bcs)) {
    thresh <- thresholds[i]
    temp.bc <- bcs[i]
    ind <- which(data.n[,temp.bc] >= thresh)
    call.mat[ind,i] <- 1
  }
  
  # Classify cells
  print("Classifying cells...")
  calls <- NULL
  temp <- rowSums(call.mat)
  for (i in 1:nrow(call.mat)) {
    if (temp[i] == 0) { calls <- c(calls, "Negative"); next }
    if (temp[i] > 1) { calls <- c(calls, "Doublet"); next }
    if (temp[i] == 1) { calls <- c(calls, colnames(call.mat)[which(call.mat[i, ] == 1)]) }
  }
  names(calls) <- rownames(data.n)
  return(calls)
}